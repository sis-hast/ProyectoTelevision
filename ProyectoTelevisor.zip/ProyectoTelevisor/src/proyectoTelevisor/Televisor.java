package proyectoTelevisor;

public class Televisor {
	private String marca;
    private double pulgadas;
    private String resolucion;
    private double precio;

    public Televisor(String marca, double pulgadas, String resolucion, double precio) {
        this.marca = marca;
        this.pulgadas = pulgadas;
        this.resolucion = resolucion;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPulgadas() {
        return pulgadas;
    }

    public void setPulgadas(double pulgadas) {
        this.pulgadas = pulgadas;
    }

    public String getResolucion() {
        return resolucion;
    }

    public void setResolucion(String resolucion) {
        this.resolucion = resolucion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void mostrarInformacion() {
        System.out.println("--- Especificaciones del Televisor ---");
        System.out.println("Marca: " + marca);
        System.out.println("Tamaño: " + pulgadas + " pulgadas");
        System.out.println("Resolución: " + resolucion);
        System.out.println("Precio: $" + precio);
    }
}
