package proyectoTelevisor;

public class TelevisorQLED extends Televisor {
	private String tecnologiaColor;

    public TelevisorQLED(String marca, double pulgadas, String resolucion, double precio, String tecnologiaColor) {
        super(marca, pulgadas, resolucion, precio);
        this.tecnologiaColor = tecnologiaColor;
    }

    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Tecnología de Color: " + tecnologiaColor);
    }
}
