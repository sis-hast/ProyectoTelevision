package proyectoTelevisor;

public class SmartTV extends Televisor {
	private String sistemaOperativo;

    public SmartTV(String marca, double pulgadas, String resolucion, double precio, String sistemaOperativo) {
        super(marca, pulgadas, resolucion, precio);
        this.sistemaOperativo = sistemaOperativo;
    }

    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Sistema Operativo: " + sistemaOperativo);
    }

}
