package proyectoTelevisor;

public class Main {

	public static void main(String[] args) {
		SmartTV smart = new SmartTV("LG", 55.0, "4K Ultra HD", 450.00, "webOS");
        TelevisorOLED oled = new TelevisorOLED("Sony", 65.0, "4K Ultra HD", 1200.00, 120);
        TelevisorQLED qled = new TelevisorQLED("Samsung", 75.0, "8K", 1500.00, "Quantum Dot");
        TelevisorCurvo curvo = new TelevisorCurvo("Xiaomi", 34.0, "WQHD", 350.00, "1500R");

        smart.mostrarInformacion();
        System.out.println();
        
        oled.mostrarInformacion();
        System.out.println();
        
        qled.mostrarInformacion();
        System.out.println();
        
        curvo.mostrarInformacion();
        System.out.println();

	}
}
