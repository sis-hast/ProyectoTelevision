package proyectoTelevisor;

public class TelevisorCurvo extends Televisor {
	private String radioCurvatura;

    public TelevisorCurvo(String marca, double pulgadas, String resolucion, double precio, String radioCurvatura) {
        super(marca, pulgadas, resolucion, precio);
        this.radioCurvatura = radioCurvatura;
    }

    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Radio de Curvatura: " + radioCurvatura);
    }
}
