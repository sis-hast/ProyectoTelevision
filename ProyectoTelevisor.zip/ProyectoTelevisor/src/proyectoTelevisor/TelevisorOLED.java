package proyectoTelevisor;

public class TelevisorOLED extends Televisor {
	private int tasaRefresco;

    public TelevisorOLED(String marca, double pulgadas, String resolucion, double precio, int tasaRefresco) {
        super(marca, pulgadas, resolucion, precio);
        this.tasaRefresco = tasaRefresco;
    }

    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Tasa de Refresco: " + tasaRefresco + " Hz");
    }
}
